import react from 'react';
import './BlogHighlights.css';


const BlogHighlights = () => {
    return (
        <div>
            <h1>Comparison page</h1>
        </div>
    );
}

export default BlogHighlights